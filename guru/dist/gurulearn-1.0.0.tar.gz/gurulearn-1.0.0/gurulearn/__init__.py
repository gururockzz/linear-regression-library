from .main import plot_linear_regression,linear_regression_accuracy

