plot_linear_regression(csv_file, x_name, y_name, x_element, y_element)
linear_regression_accuracy(csv_file, x_name, y_name, x_element, y_element)